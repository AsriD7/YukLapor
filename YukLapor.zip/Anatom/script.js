const slider = document.querySelector('.slider');
let currentIndex = 0;

setInterval(() => {
    currentIndex = (currentIndex + 1) % 3; // Assume 3 slides
    slider.style.transform = `translateX(-${currentIndex * 100}%)`;
}, 3000);

// document.getElementById("pengaduanButton").addEventListener("click", function () {
//     window.location.href = "pengaduan.html";
// });

// Ambil elemen modal dan tombol
const modal = document.getElementById('popupForm');
const openModalButton = document.getElementById('openModal');
const closeModalButton = document.getElementById('closeModal');

// Buka modal saat tombol ditekan
openModalButton.addEventListener('click', () => {
    modal.style.display = 'flex'; // Tampilkan modal
});

// Tutup modal saat tombol close ditekan
closeModalButton.addEventListener('click', () => {
    modal.style.display = 'none'; // Sembunyikan modal
});

// Tutup modal jika klik di luar konten
window.addEventListener('click', (event) => {
    if (event.target === modal) {
        modal.style.display = 'none';
    }
});

document.getElementById("openModal").addEventListener("click", function () {
    document.getElementById("popupForm").classList.add("show");
});

document.getElementById("closeModal").addEventListener("click", function () {
    document.getElementById("popupForm").classList.remove("show");
});

// Tutup modal jika klik di luar konten modal
window.addEventListener("click", function (event) {
    const modal = document.getElementById("popupForm");
    if (event.target === modal) {
        modal.classList.remove("show");
    }
});
// Ambil elemen tombol dan sidebar
const toggleSidebar = document.getElementById('toggleSidebar');
const closeSidebar = document.getElementById('closeSidebar');
const sidebar = document.getElementById('sidebar');

// Event untuk membuka sidebar
toggleSidebar.addEventListener('click', () => {
    sidebar.classList.add('open'); // Tambahkan class "open" untuk menampilkan sidebar
});

// Event untuk menutup sidebar
closeSidebar.addEventListener('click', () => {
    sidebar.classList.remove('open'); // Hapus class "open" untuk menyembunyikan sidebar
});

// Ambil semua tautan di dalam sidebar
const sidebarLinks = sidebar.querySelectorAll('a');

// Event untuk menutup sidebar saat tautan diklik
sidebarLinks.forEach(link => {
    link.addEventListener('click', () => {
        sidebar.classList.remove('open'); // Tutup sidebar
    });
});
